package cya;

public class Rectangle
{
	public float x, y, width, height;
};