package cya;

import processing.core.PVector;

public class CYAPerson
{
	
	public int id; 
	public int age; 
	public PVector centroid;  
	public PVector velocity; 
	public Rectangle boundingRect;
	public boolean dead;
	
	public CYAPerson(){
		boundingRect = new Rectangle();
		centroid = new PVector();
		velocity = new PVector();
		dead = false;
	}
	
	public void update ( CYAPerson p )
	{
		age = p.age;
		boundingRect = p.boundingRect;
		centroid = p.centroid;
		velocity = p.velocity;
	}
	
};